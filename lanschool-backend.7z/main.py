from typing import Optional
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import urllib.parse
from services.docanalyzer import knowledgeQA

app = FastAPI()

origins = [
    "*",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/hello")
def auth():
    return { "msg" : "hello" }

@app.get("/knowledgebase")
def knowledgesupport( q: Optional[str] = None):
    try:
        if q:
            answer = knowledgeQA.getSolution(urllib.parse.unquote(q))
            return { "success": True, "message": answer }

        return { "success": False, "message": "Query is missing" }

    except Exception as e:
        return { "success": False, "message": "Something went wrong" }
        

if __name__ == '__main__':
    uvicorn.run('main:app', host="0.0.0.0", port=8000, reload=True)